package com.example.asatkee1.augementedimagetest;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Initial_Page_Activity extends AppCompatActivity {
Button Science_Website;
Button general_info;
Button Departments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.initial_activity);
        getWindow().setLayout(800,800);
        getWindow().setBackgroundDrawableResource(R.drawable.backgroundwhite);
        Science_Website = findViewById(R.id.apply);
        Science_Website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bellevuecollege.edu/science/"));
                startActivity(browserIntent);
            }

        });


        general_info = findViewById(R.id.general_info);
        general_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Initial_Page_Activity.this, General_Information_Activity.class);
                Initial_Page_Activity.this.startActivity(myIntent);
            }
        });


    }
}
